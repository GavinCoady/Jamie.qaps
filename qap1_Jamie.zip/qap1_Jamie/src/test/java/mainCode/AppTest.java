package mainCode;

import org.junit.Assert;

import org.junit.Test;

import java.util.ArrayList;

public class AppTest
{
    @Test
    public void constructorTest()
    {
        App testApp = new App();
        Assert.assertTrue(testApp instanceof App);
        Assert.assertTrue(testApp.getAge() == 42);
        Assert.assertFalse(testApp.getName() == "brendan");
    }

    @Test
    public void messageDelivererTest()
    {
        App testApp = new App();
        Assert.assertEquals("test", testApp.messageDeliverer("test"));

    }

    @Test
    public void familyTest()
    {
        App testApp = new App();
        testApp.addFamilyMember("Brendan");
        testApp.addFamilyMember("Kendall");
        ArrayList<String> testFamily = new ArrayList<>();
        testFamily.add("Brendan");
        testFamily.add("Kendall");
        Assert.assertEquals(testApp.getFamilyMembers(), testFamily);
    }

}
