package mainCode;

import java.util.ArrayList;


// classes
public class App
{
    private String name = "Brendan";
    private Integer age = 42;
    private ArrayList<String> familyMembers;
    public App(){
        this.familyMembers = new ArrayList<String>();
    }
    public String messageDeliverer(String message)
    {
        return message;
    }




    // Getters and setters

    public String getName()
    {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge()
    {
        return this.age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public ArrayList<String> getFamilyMembers() {
        return familyMembers;
    }

    public void setFamilyMembers(ArrayList<String> familyMembers) {
        this.familyMembers = familyMembers;
    }

    public void addFamilyMember(String name) {
        this.familyMembers.add(name);
    }
}
